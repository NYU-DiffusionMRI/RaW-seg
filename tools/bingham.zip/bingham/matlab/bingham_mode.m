function x = bingham_mode(B)
% x = bingham_mode(B)

x = crossnd(B.V);
